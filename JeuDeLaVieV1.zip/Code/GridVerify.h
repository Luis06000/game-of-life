#pragma once

class GridVerify {
private:
    bool isEmpty;
    bool isEqual;

public:
    bool GetIsEmpty() const;
    bool GetIsEqual() const;
};

