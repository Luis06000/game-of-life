#include "GridVerify.h"

bool GridVerify::GetIsEmpty() const {
    return isEmpty;
}

bool GridVerify::GetIsEqual() const {
    return isEqual;
}
